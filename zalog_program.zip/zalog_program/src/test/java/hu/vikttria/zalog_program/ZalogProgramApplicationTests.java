package hu.vikttria.zalog_program;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ZalogProgramApplicationTests {

	@Test
	void contextLoads() {
	}

}
