package hu.vikttria.zalog_program;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ZalogProgramApplication {

	public static void main(String[] args) {
		SpringApplication.run(ZalogProgramApplication.class, args);
	}

}
